"""Autentica en Consuman y extrae Ordenes de Trabajo a JSON.

Esta etapa conserva el flujo de login normal. La llamada a la API se ejecuta con
``fetch`` dentro de la pagina autenticada, por lo que usa automaticamente las
cookies de la sesion creada por Playwright.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any

from playwright.sync_api import (
    Error as PlaywrightError,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)


LOGIN_URL = "https://panoi.consumannet.com.ar/Login.aspx"
WORK_ORDERS_URL = "https://panoi.consumannet.com.ar/Operational/WorkOrders.aspx"
API_URL = "https://panoi.consumannet.com.ar/api/workOrder/get-grid"
TASK_API_URL = "https://panoi.consumannet.com.ar/api/workOrderTask/get-grid"
OUTPUT_PATH = Path(__file__).resolve().parent / "ordenes_trabajo.json"
EXCEL_PATH = Path(__file__).resolve().parent / "ordenes_trabajo_Uruguay.xlsx"
BUILDER_PATH = Path(__file__).resolve().parent / "build_excel.mjs"
TIMEOUT_MS = 60_000


class ConsumanError(RuntimeError):
    """Error legible durante la automatizacion de Consuman."""


def read_credentials() -> tuple[str, str]:
    username = os.getenv("CONSUMAN_USUARIO", "").strip()
    password = os.getenv("CONSUMAN_PASSWORD", "")
    missing = [
        name
        for name, value in (
            ("CONSUMAN_USUARIO", username),
            ("CONSUMAN_PASSWORD", password),
        )
        if not value
    ]
    if missing:
        raise ConsumanError(
            "Faltan variables de entorno: "
            + ", ".join(missing)
            + ". Definalas antes de ejecutar."
        )
    return username, password


def read_date(name: str, default: date) -> date:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return date.fromisoformat(raw)
    except ValueError as exc:
        raise ConsumanError(f"{name} debe usar el formato AAAA-MM-DD: {raw!r}") from exc


def iso_utc(day: date, end_of_day: bool = False) -> str:
    clock = time(23, 59, 59, 999000) if end_of_day else time.min
    value = datetime.combine(day, clock, tzinfo=timezone.utc)
    return value.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def iso_datetime_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace(
        "+00:00", "Z"
    )


def build_payload() -> dict[str, Any]:
    now = datetime.now().astimezone()
    today = now.date()
    from_date = read_date("CONSUMAN_DESDE", today - timedelta(days=30))
    to_date = read_date("CONSUMAN_HASTA", today + timedelta(days=30))
    if from_date > to_date:
        raise ConsumanError("CONSUMAN_DESDE no puede ser posterior a CONSUMAN_HASTA.")

    if os.getenv("CONSUMAN_DESDE", "").strip():
        from_value = datetime.combine(from_date, time.min).astimezone()
    else:
        from_value = now - timedelta(days=30)
    if os.getenv("CONSUMAN_HASTA", "").strip():
        to_value = datetime.combine(to_date, time(23, 59, 59, 999000)).astimezone()
    else:
        to_value = now + timedelta(days=30)

    return {
        "fromDate": iso_datetime_utc(from_value),
        "toDate": iso_datetime_utc(to_value),
        "daysAfter": 30,
        "daysBefore": 30,
        "equipment": [],
        "project": [],
        "staff": [],
        "taskType": [],
        "periodRange": True,
        # Incluye todos los estados de OT para no omitir ordenes recientes,
        # canceladas o en transiciones que la vista predeterminada no marca.
        "woState": [{"id": value} for value in (1, 2, 3, 4, 5)],
        "woStatesTask": [{"id": value} for value in (0, 2, 3)],
        "period": [{"id": 6}],
        "layout": [],
        "loadOptions": {
            "skip": 0,
            "take": 25,
            "requireTotalCount": True,
            "sort": [
                {"selector": "date", "desc": True},
                {"selector": "type", "desc": True},
            ],
        },
    }


def is_login_page(page) -> bool:
    return (
        "login.aspx" in page.url.lower()
        or page.locator('input[name="username"]').count() > 0
    )


def login(page, username: str, password: str) -> None:
    print(f"Abriendo login: {LOGIN_URL}")
    page.goto(LOGIN_URL, wait_until="domcontentloaded")
    user_input = page.locator('input[name="username"]')
    password_input = page.locator('input[name="password"]')
    login_button = page.locator("button", has_text="Login")
    user_input.wait_for(state="visible")
    password_input.wait_for(state="visible")
    login_button.wait_for(state="visible")
    user_input.fill(username)
    password_input.fill(password)
    login_button.click()
    user_input.wait_for(state="hidden", timeout=TIMEOUT_MS)
    page.wait_for_load_state("domcontentloaded")
    if is_login_page(page):
        raise ConsumanError("El login no fue aceptado. Verifique las credenciales.")


def extract_orders(page, payload: dict[str, Any]) -> Any:
    observed_requests: list[dict[str, Any]] = []

    def observe_request(request) -> None:
        if "/api/workorder/get-grid" not in request.url.lower():
            return
        safe_headers = {
            key: value
            for key, value in request.headers.items()
            if key.lower() in {
                "accept",
                "content-type",
                "requestverificationtoken",
                "x-requested-with",
                "x-xsrf-token",
            }
        }
        observed_requests.append(
            {
                "method": request.method,
                "headers": safe_headers,
                "postData": request.post_data,
            }
        )

    page.on("request", observe_request)
    print(f"Navegando a Ordenes de Trabajo: {WORK_ORDERS_URL}")
    response = page.goto(WORK_ORDERS_URL, wait_until="domcontentloaded")
    page.locator("body").wait_for(state="visible")
    if response is not None and response.status >= 400:
        raise ConsumanError(f"La pagina devolvio HTTP {response.status}.")
    if is_login_page(page):
        raise ConsumanError("La sesion expiro o no quedo autenticada.")

    # Da tiempo a que la aplicacion haga su propia carga inicial. La observacion
    # solo conserva encabezados no sensibles y nunca copia cookies.
    page.wait_for_timeout(3_000)

    print(f"Consultando API para {payload['fromDate']} a {payload['toDate']}...")
    result = page.evaluate(
        """async ({ apiUrl, payload }) => {
            const allRows = [];
            let totalCount = null;
            let skip = 0;
            const take = 25;
            while (totalCount === null || skip < totalCount) {
                const pagePayload = {
                    ...payload,
                    loadOptions: { ...payload.loadOptions, skip, take, requireTotalCount: true },
                };
                const response = await fetch(apiUrl, {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    body: JSON.stringify(pagePayload),
                });
                const bodyText = await response.text();
                let data = null;
                try { data = JSON.parse(bodyText); } catch (_) {}
                if (!response.ok || data === null) {
                    return {
                        ok: false,
                        status: response.status,
                        statusText: response.statusText,
                        contentType: response.headers.get("content-type"),
                        data,
                        bodyPreview: bodyText.slice(0, 500),
                        failedSkip: skip,
                    };
                }
                const rows = Array.isArray(data) ? data : (data.data || data.rows || []);
                if (!Array.isArray(rows)) {
                    return { ok: false, status: 200, statusText: "Formato inesperado", data: null, bodyPreview: bodyText.slice(0, 500), failedSkip: skip };
                }
                allRows.push(...rows);
                totalCount = Number.isFinite(Number(data.totalCount)) ? Number(data.totalCount) : allRows.length;
                if (rows.length === 0 || rows.length < take) break;
                skip += take;
            }
            return {
                ok: true,
                status: 200,
                statusText: "OK",
                contentType: "application/json",
                data: { data: allRows, totalCount: totalCount ?? allRows.length },
                bodyPreview: "",
            };
        }""",
        {"apiUrl": API_URL, "payload": payload},
    )
    if not result["ok"]:
        diagnostic_path = OUTPUT_PATH.with_name("diagnostico_get_grid.json")
        diagnostic = {
            "attemptedPayload": payload,
            "httpStatus": result["status"],
            "bodyPreview": result["bodyPreview"],
            "observedPageRequests": observed_requests,
        }
        with diagnostic_path.open("w", encoding="utf-8", newline="\n") as file:
            json.dump(diagnostic, file, ensure_ascii=False, indent=2)
            file.write("\n")
        raise ConsumanError(
            f"La API devolvio HTTP {result['status']} {result['statusText']}. "
            f"Respuesta: {result['bodyPreview']!r}. Se guardo un diagnostico "
            f"sin cookies en {diagnostic_path}."
        )
    if result["data"] is None:
        raise ConsumanError(
            "La API no devolvio JSON. Content-Type: "
            + str(result.get("contentType"))
        )
    return result["data"]


def extract_tasks(page, payload: dict[str, Any]) -> Any:
    """Obtiene las tareas reales de la grilla Detalles de Consuman."""
    task_payload = {
        **payload,
        # La exportacion debe incluir tareas realizadas, pendientes, canceladas
        # y sin realizar. La vista predeterminada omite las realizadas.
        "woStatesTask": [{"id": value} for value in (0, 1, 2, 3)],
        "loadOptions": {
            "skip": 0,
            "take": 100,
            "requireTotalCount": True,
            "sort": [{"selector": "plannedDate", "desc": True}],
        },
    }
    print("Consultando tareas reales de la grilla Detalles...")
    result = page.evaluate(
        """async ({ apiUrl, payload }) => {
            const allRows = [];
            let totalCount = null;
            let skip = 0;
            const take = 100;
            while (totalCount === null || skip < totalCount) {
                const pagePayload = {
                    ...payload,
                    loadOptions: { ...payload.loadOptions, skip, take, requireTotalCount: true },
                };
                const response = await fetch(apiUrl, {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    body: JSON.stringify(pagePayload),
                });
                const bodyText = await response.text();
                let data = null;
                try { data = JSON.parse(bodyText); } catch (_) {}
                if (!response.ok || data === null) {
                    return { ok: false, status: response.status, bodyPreview: bodyText.slice(0, 500) };
                }
                const rows = Array.isArray(data) ? data : (data.data || data.rows || []);
                if (!Array.isArray(rows)) {
                    return { ok: false, status: 200, bodyPreview: bodyText.slice(0, 500) };
                }
                allRows.push(...rows);
                totalCount = Number.isFinite(Number(data.totalCount)) ? Number(data.totalCount) : allRows.length;
                if (rows.length === 0 || rows.length < take) break;
                skip += take;
            }
            return { ok: true, data: { data: allRows, totalCount: totalCount ?? allRows.length } };
        }""",
        {"apiUrl": TASK_API_URL, "payload": task_payload},
    )
    if not result["ok"]:
        raise ConsumanError(
            f"No se pudieron obtener las tareas (HTTP {result['status']}): "
            f"{result['bodyPreview']!r}"
        )
    return result["data"]


def add_task_names(orders_data: Any, tasks_data: Any) -> Any:
    orders = orders_data.get("data", []) if isinstance(orders_data, dict) else orders_data
    tasks = tasks_data.get("data", []) if isinstance(tasks_data, dict) else tasks_data
    if not isinstance(orders, list) or not isinstance(tasks, list):
        raise ConsumanError("Consuman devolvio un formato inesperado al combinar tareas.")

    tasks_by_order: dict[str, list[str]] = {}
    for task in tasks:
        if not isinstance(task, dict):
            continue
        key = str(task.get("workOrderId") or task.get("workOrderNumber") or "")
        name = str(task.get("task") or "").strip()
        if not key or not name:
            continue
        names = tasks_by_order.setdefault(key, [])
        if name not in names:
            names.append(name)

    for order in orders:
        if not isinstance(order, dict):
            continue
        key = str(order.get("id") or order.get("number") or "")
        names = tasks_by_order.get(key, [])
        order["task"] = " | ".join(names)
        order["tasks"] = names
    return orders_data


def count_records(data: Any) -> int | None:
    if isinstance(data, list):
        return len(data)
    if isinstance(data, dict):
        for key in ("data", "rows", "items", "result", "workOrders"):
            if isinstance(data.get(key), list):
                return len(data[key])
    return None


def save_json_atomic(data: Any) -> None:
    temp_path = OUTPUT_PATH.with_suffix(".json.tmp")
    with temp_path.open("w", encoding="utf-8", newline="\n") as file:
        json.dump(data, file, ensure_ascii=False, indent=2)
        file.write("\n")
    os.replace(temp_path, OUTPUT_PATH)


def find_node() -> str:
    configured = os.getenv("CONSUMAN_NODE", "").strip()
    candidates = [
        configured,
        shutil.which("node") or "",
        str(
            Path.home()
            / ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe"
        ),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return candidate
    raise ConsumanError(
        "No se encontro Node.js para generar el Excel. Defina CONSUMAN_NODE "
        "con la ruta completa a node.exe. El JSON fue guardado correctamente."
    )


def generate_excel() -> None:
    node = find_node()
    temp_excel = EXCEL_PATH.with_name("ordenes_trabajo_Uruguay.nuevo.xlsx")
    preview = EXCEL_PATH.with_name("ordenes_trabajo_Uruguay_preview.png")
    try:
        completed = subprocess.run(
            [
                node,
                str(BUILDER_PATH),
                str(OUTPUT_PATH),
                str(temp_excel),
                str(preview),
            ],
            cwd=OUTPUT_PATH.parent,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise ConsumanError("La generacion del Excel excedio 120 segundos.") from exc
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout)[-1000:].strip()
        raise ConsumanError(f"No se pudo generar el Excel: {detail}")
    if not temp_excel.is_file():
        raise ConsumanError("El generador finalizo sin crear el archivo Excel.")
    try:
        os.replace(temp_excel, EXCEL_PATH)
    except PermissionError as exc:
        raise ConsumanError(
            f"No se puede reemplazar {EXCEL_PATH.name} porque esta abierto en Excel. "
            "Cierre el archivo y vuelva a ejecutar. La extraccion JSON se completo."
        ) from exc


def run() -> None:
    username, password = read_credentials()
    payload = build_payload()
    headless = os.getenv("CONSUMAN_HEADLESS", "0").strip().lower() in {
        "1", "true", "si", "yes"
    }

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=headless)
        context = browser.new_context()
        page = context.new_page()
        page.set_default_timeout(TIMEOUT_MS)
        try:
            login(page, username, password)
            data = extract_orders(page, payload)
            tasks = extract_tasks(page, payload)
            data = add_task_names(data, tasks)
            save_json_atomic(data)
            count = count_records(data)
            suffix = f" ({count} registros detectados)" if count is not None else ""
            print(f"OK: JSON guardado en {OUTPUT_PATH}{suffix}.")
            if os.getenv("CONSUMAN_SKIP_EXCEL", "0").strip().lower() not in {"1", "true", "si", "yes"}:
                print("Generando Excel...")
                generate_excel()
                print(f"OK: Excel actualizado en {EXCEL_PATH}.")
            else:
                print("Excel omitido (CONSUMAN_SKIP_EXCEL=1).")
        except PlaywrightTimeoutError as exc:
            raise ConsumanError(
                f"Consuman no respondio dentro de {TIMEOUT_MS // 1000} segundos. "
                f"URL actual: {page.url}"
            ) from exc
        finally:
            context.close()
            browser.close()


def main() -> int:
    try:
        run()
        return 0
    except ConsumanError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except PlaywrightError as exc:
        print(f"ERROR de Playwright: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"ERROR al guardar el archivo: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nProceso cancelado por el usuario.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
